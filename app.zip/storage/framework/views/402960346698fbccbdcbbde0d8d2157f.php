<?php $__env->startSection('page_title', 'FAQs'); ?>
<?php $__env->startSection('page_subtitle', 'Manage frequently asked questions'); ?>
<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.faqs.create')); ?>"
        class="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg shadow hover:bg-primary/90">New
        FAQ</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="GET" class="mb-4 flex flex-col sm:flex-row gap-3 items-start sm:items-center">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search questions and answers"
            class="w-full sm:w-72 border rounded-lg px-3 py-2" />
        <select name="status" class="border rounded-lg px-3 py-2">
            <option value="">All statuses</option>
            <option value="published" <?php echo e(request('status') === 'published' ? 'selected' : ''); ?>>Published</option>
            <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
        </select>
        <button class="inline-flex items-center gap-2 px-4 py-2 bg-gray-900 text-white rounded-lg">Filter</button>
        <?php if(request()->hasAny(['q', 'status'])): ?>
            <a href="<?php echo e(route('admin.faqs.index')); ?>" class="text-sm text-gray-600 underline">Reset</a>
        <?php endif; ?>
    </form>
    <div class="bg-white/90 backdrop-blur rounded-xl shadow ring-1 ring-black/5">
        <div class="overflow-x-auto">
            <table class="min-w-full">
                <thead>
                    <tr class="text-left bg-gray-50 border-b">
                        <th class="p-3 text-sm font-semibold text-gray-600">Question</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Published</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Last updated</th>
                        <th class="p-3"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3"><?php echo e($faq->question); ?></td>
                            <td class="p-3">
                                <?php if($faq->is_published): ?>
                                    <span
                                        class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-green-50 text-green-700 ring-1 ring-green-200">Published</span>
                                <?php else: ?>
                                    <span
                                        class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-700 ring-1 ring-gray-200">Draft</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-sm text-gray-600"><?php echo e(optional($faq->updated_at)->diffForHumans()); ?></td>
                            <td class="p-3 text-right space-x-2">
                                <form action="<?php echo e(route('admin.faqs.toggle-publish', $faq)); ?>" method="POST" class="inline"
                                    onsubmit="return <?php echo e($faq->is_published ? 'confirm(\'Unpublish this FAQ?\')' : 'true'); ?>;">
                                    <?php echo csrf_field(); ?>
                                    <button
                                        class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm <?php echo e($faq->is_published ? 'bg-amber-600 hover:bg-amber-500' : 'bg-green-600 hover:bg-green-500'); ?> text-white">
                                        <?php echo e($faq->is_published ? 'Unpublish' : 'Publish'); ?>

                                    </button>
                                </form>
                                <a href="<?php echo e(route('admin.faqs.edit', $faq)); ?>"
                                    class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm bg-blue-600 text-white hover:bg-blue-500">Edit</a>
                                <button
                                    class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm bg-red-600 text-white hover:bg-red-500"
                                    x-data
                                    @click="$dispatch('open-modal', 'delete-faq-<?php echo e($faq->id); ?>')">Delete</button>

                                <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'delete-faq-'.e($faq->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'delete-faq-'.e($faq->id).'']); ?>
                                    <div class="p-6">
                                        <h3 class="text-lg font-semibold">Delete FAQ</h3>
                                        <p class="text-gray-600 mt-1">Are you sure you want to delete this FAQ? This action
                                            cannot
                                            be undone.</p>
                                        <div class="mt-6 flex justify-end gap-3">
                                            <button class="px-4 py-2 rounded-lg bg-gray-100"
                                                x-on:click="$dispatch('close-modal', 'delete-faq-<?php echo e($faq->id); ?>')">Cancel</button>
                                            <form action="<?php echo e(route('admin.faqs.destroy', $faq)); ?>" method="POST"
                                                onsubmit="return confirm('Delete this FAQ permanently?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="px-4 py-2 rounded-lg bg-red-600 text-white">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-4"><?php echo e($faqs->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/admin/faqs/index.blade.php ENDPATH**/ ?>