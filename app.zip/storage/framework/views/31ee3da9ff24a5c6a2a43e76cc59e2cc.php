<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin · <?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body class="bg-gray-50 text-gray-900" data-no-aos="true">
    <div x-data="{ sidebarOpen: false }" class="min-h-screen flex">
        <!-- Sidebar -->
        <aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'"
            class="fixed inset-y-0 left-0 z-40 w-72 transform transition-transform duration-200 ease-in-out bg-accent-black text-white md:translate-x-0">
            <div class="h-full flex flex-col">
                <div class="flex items-center gap-3 px-5 h-16 border-b border-white/10">
                    <a href="/" class="flex items-center gap-2">
                        <img src="<?php echo e(Vite::asset('resources/images/logo wide white.png')); ?>"
                            alt="<?php echo e(config('app.name')); ?>" class="h-8">
                    </a>
                </div>
                <nav class="flex-1 overflow-y-auto py-4 minimal-scrollbar">
                    <?php
                        $linkBase = 'block px-5 py-3 rounded-xl mx-3 mb-1.5 transition hover:bg-white/10';
                        $active = 'bg-white/10 text-white';
                        $inactive = 'text-white/70';
                    ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="<?php echo e($linkBase); ?> <?php echo e(request()->routeIs('admin.dashboard') ? $active : $inactive); ?>">
                        <span>Dashboard</span>
                    </a>
                    <a href="<?php echo e(route('admin.blog-posts.index')); ?>"
                        class="<?php echo e($linkBase); ?> <?php echo e(request()->routeIs('admin.blog-posts.*') ? $active : $inactive); ?>">
                        <span>Blog Posts</span>
                    </a>
                    <a href="<?php echo e(route('admin.career-posts.index')); ?>"
                        class="<?php echo e($linkBase); ?> <?php echo e(request()->routeIs('admin.career-posts.*') ? $active : $inactive); ?>">
                        <span>Career Posts</span>
                    </a>
                    <a href="<?php echo e(route('admin.faqs.index')); ?>"
                        class="<?php echo e($linkBase); ?> <?php echo e(request()->routeIs('admin.faqs.*') ? $active : $inactive); ?>">
                        <span>FAQs</span>
                    </a>
                    <a href="<?php echo e(route('admin.testimonials.index')); ?>"
                        class="<?php echo e($linkBase); ?> <?php echo e(request()->routeIs('admin.testimonials.*') ? $active : $inactive); ?>">
                        <span>Testimonials</span>
                    </a>
                </nav>
                <div class="p-4 mt-auto border-t border-white/10">
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="flex">
                        <?php echo csrf_field(); ?>
                        <button
                            class="w-full inline-flex justify-center items-center gap-2 rounded-lg bg-primary text-primary-3 font-semibold py-2.5 hover:brightness-95 transition">
                            Log out
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        <!-- Main content area -->
        <div class="flex-1 min-w-0 md:ml-72">
            <!-- Top bar -->
            <header class="sticky top-0 z-30 bg-white/80 backdrop-blur border-b border-gray-200">
                <div class="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <button @click="sidebarOpen = !sidebarOpen" class="md:hidden p-2 rounded-lg hover:bg-gray-100">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"
                                class="w-6 h-6 text-gray-700">
                                <path fill-rule="evenodd"
                                    d="M3.75 5.25A.75.75 0 014.5 4.5h15a.75.75 0 010 1.5h-15a.75.75 0 01-.75-.75zm0 7.5a.75.75 0 01.75-.75h15a.75.75 0 010 1.5h-15a.75.75 0 01-.75-.75zm.75 6.75a.75.75 0 000 1.5h15a.75.75 0 000-1.5h-15z"
                                    clip-rule="evenodd" />
                            </svg>
                        </button>
                        <h1 class="text-lg font-semibold">Admin</h1>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="hidden sm:block text-sm text-gray-500"><?php echo e(auth()->user()->name ?? 'Admin'); ?></div>
                        <div class="h-9 w-9 rounded-full bg-gray-200"></div>
                    </div>
                </div>
            </header>

            <!-- Page content -->
            <main class="max-w-7xl mx-auto px-5 md:px-8 py-6">
                <?php if(session('status')): ?>
                    <div class="p-3 bg-green-50 border border-green-200 text-green-700 rounded mb-4">
                        <?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php if(trim($__env->yieldContent('page_title'))): ?>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
                        <div>
                            <h2 class="text-xl font-semibold"><?php echo $__env->yieldContent('page_title'); ?></h2>
                            <?php if(trim($__env->yieldContent('page_subtitle'))): ?>
                                <p class="text-gray-500 mt-1 text-sm"><?php echo $__env->yieldContent('page_subtitle'); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center gap-2"><?php echo $__env->yieldContent('page_actions'); ?></div>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>

<?php echo $__env->yieldPushContent('scripts'); ?>

</html>
<?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/admin/layout.blade.php ENDPATH**/ ?>