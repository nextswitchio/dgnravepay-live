<?php $__env->startSection('page_title', 'Career Posts'); ?>
<?php $__env->startSection('page_subtitle', 'Create, edit and publish job posts'); ?>
<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.career-posts.create')); ?>"
        class="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg shadow hover:bg-primary/90">New
        Job</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="GET" class="mb-4 flex flex-col sm:flex-row gap-3 items-start sm:items-center">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search title, dept, location, type"
            class="w-full sm:w-72 border rounded-lg px-3 py-2" />
        <select name="status" class="border rounded-lg px-3 py-2">
            <option value="">All statuses</option>
            <option value="published" <?php echo e(request('status') === 'published' ? 'selected' : ''); ?>>Published</option>
            <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
        </select>
        <button class="inline-flex items-center gap-2 px-4 py-2 bg-gray-900 text-white rounded-lg">Filter</button>
        <?php if(request()->hasAny(['q', 'status'])): ?>
            <a href="<?php echo e(route('admin.career-posts.index')); ?>" class="text-sm text-gray-600 underline">Reset</a>
        <?php endif; ?>
    </form>
    <div class="bg-white/90 backdrop-blur rounded-xl shadow ring-1 ring-black/5">
        <div class="overflow-x-auto">
            <table class="min-w-full">
                <thead>
                    <tr class="text-left bg-gray-50 border-b">
                        <th class="p-3 text-sm font-semibold text-gray-600">Title</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Cover</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Slug</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Department</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Type</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Published</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Published at</th>
                        <th class="p-3 text-sm font-semibold text-gray-600">Last updated</th>
                        <th class="p-3"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3"><?php echo e($post->title); ?></td>
                            <td class="p-3">
                                <?php if($post->cover_image_path): ?>
                                    <img src="<?php echo e(asset('storage/' . $post->cover_image_path)); ?>" alt="cover"
                                        class="h-10 w-16 object-cover rounded">
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-sm text-gray-700">
                                <div class="flex items-center gap-2">
                                    <span class="truncate max-w-[200px]"
                                        title="<?php echo e($post->slug); ?>"><?php echo e($post->slug); ?></span>
                                    <button type="button" class="text-xs px-2 py-1 rounded bg-gray-100 hover:bg-gray-200"
                                        onclick="navigator.clipboard.writeText('<?php echo e(url('/career/' . $post->slug)); ?>');this.innerText='Copied';setTimeout(()=>this.innerText='Copy link',1200);">Copy
                                        link</button>
                                    <button type="button" class="text-xs px-2 py-1 rounded bg-gray-100 hover:bg-gray-200"
                                        onclick="navigator.clipboard.writeText('<?php echo e($post->slug); ?>');this.innerText='Copied';setTimeout(()=>this.innerText='Copy slug',1200);">Copy
                                        slug</button>
                                </div>
                            </td>
                            <td class="p-3"><?php echo e($post->department); ?></td>
                            <td class="p-3"><?php echo e($post->employment_type); ?></td>
                            <td class="p-3">
                                <?php if($post->is_published): ?>
                                    <span
                                        class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-green-50 text-green-700 ring-1 ring-green-200">Published</span>
                                <?php else: ?>
                                    <span
                                        class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-700 ring-1 ring-gray-200">Draft</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-sm text-gray-600"
                                title="<?php echo e(optional($post->published_at)->toDayDateTimeString()); ?>">
                                <?php echo e(optional($post->published_at)->format('Y-m-d H:i') ?? '—'); ?></td>
                            <td class="p-3 text-sm text-gray-600"><?php echo e(optional($post->updated_at)->diffForHumans()); ?></td>
                            <td class="p-3 text-right space-x-2">
                                <form action="<?php echo e(route('admin.career-posts.toggle-publish', $post)); ?>" method="POST"
                                    class="inline"
                                    onsubmit="return <?php echo e($post->is_published ? 'confirm(\'Unpublish this job?\')' : 'true'); ?>;">
                                    <?php echo csrf_field(); ?>
                                    <button
                                        class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm <?php echo e($post->is_published ? 'bg-amber-600 hover:bg-amber-500' : 'bg-green-600 hover:bg-green-500'); ?> text-white">
                                        <?php echo e($post->is_published ? 'Unpublish' : 'Publish'); ?>

                                    </button>
                                </form>
                                <a href="<?php echo e(route('admin.career-posts.edit', $post)); ?>"
                                    class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm bg-blue-600 text-white hover:bg-blue-500">Edit</a>
                                <button
                                    class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm bg-red-600 text-white hover:bg-red-500"
                                    x-data
                                    @click="$dispatch('open-modal', 'delete-career-<?php echo e($post->id); ?>')">Delete</button>

                                <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'delete-career-'.e($post->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'delete-career-'.e($post->id).'']); ?>
                                    <div class="p-6">
                                        <h3 class="text-lg font-semibold">Delete career post</h3>
                                        <p class="text-gray-600 mt-1">Are you sure you want to delete
                                            "<?php echo e($post->title); ?>"?
                                            This
                                            action cannot be undone.</p>
                                        <div class="mt-6 flex justify-end gap-3">
                                            <button class="px-4 py-2 rounded-lg bg-gray-100"
                                                x-on:click="$dispatch('close-modal', 'delete-career-<?php echo e($post->id); ?>')">Cancel</button>
                                            <form action="<?php echo e(route('admin.career-posts.destroy', $post)); ?>" method="POST"
                                                onsubmit="return confirm('Delete this career post permanently?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="px-4 py-2 rounded-lg bg-red-600 text-white">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-4"><?php echo e($posts->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/admin/career_posts/index.blade.php ENDPATH**/ ?>