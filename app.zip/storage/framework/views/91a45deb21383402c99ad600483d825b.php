<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => 'Get Savvy About Your Financial Life',
    'description' =>
        'See why over 100,000 Nigerians have made DgnRavePay their go-to financial app. Real reviews, real stories, real results.',
    'limit' => null,
    // Optional: pass a $faqs collection from a controller to override internal query.
    'faqs' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => 'Get Savvy About Your Financial Life',
    'description' =>
        'See why over 100,000 Nigerians have made DgnRavePay their go-to financial app. Real reviews, real stories, real results.',
    'limit' => null,
    // Optional: pass a $faqs collection from a controller to override internal query.
    'faqs' => null,
]); ?>
<?php foreach (array_filter(([
    'title' => 'Get Savvy About Your Financial Life',
    'description' =>
        'See why over 100,000 Nigerians have made DgnRavePay their go-to financial app. Real reviews, real stories, real results.',
    'limit' => null,
    // Optional: pass a $faqs collection from a controller to override internal query.
    'faqs' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    // Load published FAQs if not provided, preserving the current design style
    if (!isset($faqs) || $faqs === null) {
        $query = \App\Models\Faq::query()->where('is_published', true)->latest('updated_at');
        if (!empty($limit)) {
            $query->limit((int) $limit);
        }
        $faqs = $query->get();
    }
?>

<div id="faqs">
    <div class="mb-10 px-5 md:px-10" data-aos="fade-up">
        <h2 class="text-center mb-5"><?php echo e($title); ?></h2>
        <p class="text-center"><?php echo e($description); ?></p>
    </div>
    <ul class="max-w-4xl mx-auto space-y-2 md:space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="flex items-center justify-between bg-stone-100 rounded-2xl py-3 md:py-4 px-3 md:px-5">
                <details>
                    <summary class="font-medium text-sm md:text-lg"><?php echo e($faq->question); ?></summary>
                    <p class="mt-2"><?php echo nl2br(e($faq->answer)); ?></p>
                </details>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="text-center text-gray-500 py-6">No FAQs available at the moment.</li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/components/pages/faq-section.blade.php ENDPATH**/ ?>