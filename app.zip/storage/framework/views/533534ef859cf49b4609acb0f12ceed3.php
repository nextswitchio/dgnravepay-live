<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => config('app.name'),
    'description' => null,
    'canonical' => null,
    'image' => null,
    'type' => 'website',
    'noindex' => false,
    'jsonLd' => null,
    'onlyJsonLd' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => config('app.name'),
    'description' => null,
    'canonical' => null,
    'image' => null,
    'type' => 'website',
    'noindex' => false,
    'jsonLd' => null,
    'onlyJsonLd' => false,
]); ?>
<?php foreach (array_filter(([
    'title' => config('app.name'),
    'description' => null,
    'canonical' => null,
    'image' => null,
    'type' => 'website',
    'noindex' => false,
    'jsonLd' => null,
    'onlyJsonLd' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $siteName = config('app.name');
    $fullTitle = $title ? $title . ' | ' . $siteName : $siteName;
    $url = $canonical ?? url()->current();
    $desc = $description ?? strip_tags($description ?? '');
    $img = $image ?? url(Vite::asset('resources/images/logo wide.png'));

    // Provide sensible default JSON-LD (Organization + WebSite) if none supplied
    $appUrl = config('app.url') ?? url('/');
    $defaultJsonLd = [
        [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => $siteName,
            'url' => $appUrl,
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => $siteName,
            'url' => $appUrl,
        ],
    ];
    $schemaToRender = $jsonLd ?? $defaultJsonLd;
?>

<?php if (! ($onlyJsonLd)): ?>
    <title><?php echo e($fullTitle); ?></title>
    <?php if($desc): ?>
        <meta name="description" content="<?php echo e($desc); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo e($url); ?>" />
    <?php if($noindex): ?>
        <meta name="robots" content="noindex,nofollow" />
    <?php endif; ?>

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="<?php echo e($type); ?>">
    <meta property="og:title" content="<?php echo e($fullTitle); ?>">
    <?php if($desc): ?>
        <meta property="og:description" content="<?php echo e($desc); ?>">
    <?php endif; ?>
    <meta property="og:url" content="<?php echo e($url); ?>">
    <meta property="og:site_name" content="<?php echo e($siteName); ?>">
    <?php if($img): ?>
        <meta property="og:image" content="<?php echo e($img); ?>">
    <?php endif; ?>

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($fullTitle); ?>">
    <?php if($desc): ?>
        <meta name="twitter:description" content="<?php echo e($desc); ?>">
    <?php endif; ?>
    <?php if($img): ?>
        <meta name="twitter:image" content="<?php echo e($img); ?>">
    <?php endif; ?>
<?php endif; ?>

<?php if(!empty($schemaToRender)): ?>
    <script type="application/ld+json"><?php echo json_encode($schemaToRender, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); ?></script>
<?php endif; ?>
<?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/components/seo.blade.php ENDPATH**/ ?>