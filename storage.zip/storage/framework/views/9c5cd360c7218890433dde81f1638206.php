<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php if(request()->is('/') || request()->is('savings') || request()->is('business')): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/index.js']); ?>
        
        <?php elseif(request()->is('about') || request()->is('career')): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/about.js']); ?>
            
        <?php endif; ?>
    </head>
    <body class="font-sans antialiased <?php echo e(request()->is('about') ? 'bg-accent-black text-white' : 'text-gray-900'); ?>">
        <?php if (isset($component)) { $__componentOriginal8c1b382543e4a0f754cb1109547c7c68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c1b382543e4a0f754cb1109547c7c68 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pages.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c1b382543e4a0f754cb1109547c7c68)): ?>
<?php $attributes = $__attributesOriginal8c1b382543e4a0f754cb1109547c7c68; ?>
<?php unset($__attributesOriginal8c1b382543e4a0f754cb1109547c7c68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c1b382543e4a0f754cb1109547c7c68)): ?>
<?php $component = $__componentOriginal8c1b382543e4a0f754cb1109547c7c68; ?>
<?php unset($__componentOriginal8c1b382543e4a0f754cb1109547c7c68); ?>
<?php endif; ?>
        

        <div class="">
            <?php echo e($slot); ?>

        </div>

        <?php if (isset($component)) { $__componentOriginale1a5dc06883efde99c738294c04804ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1a5dc06883efde99c738294c04804ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pages.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $attributes = $__attributesOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__attributesOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $component = $__componentOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__componentOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH C:\Users\HP\workspace\dgnravepay-live-main\resources\views/layouts/guest.blade.php ENDPATH**/ ?>