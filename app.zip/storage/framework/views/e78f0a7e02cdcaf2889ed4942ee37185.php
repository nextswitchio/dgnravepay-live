<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <?php if (isset($component)) { $__componentOriginal42da61123f891e63201d7be28f403427 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42da61123f891e63201d7be28f403427 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seo','data' => ['title' => trim($__env->yieldContent('title') ?? config('app.name', 'Laravel')),'description' => trim($__env->yieldContent('meta_description') ?? '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('seo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trim($__env->yieldContent('title') ?? config('app.name', 'Laravel'))),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trim($__env->yieldContent('meta_description') ?? ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42da61123f891e63201d7be28f403427)): ?>
<?php $attributes = $__attributesOriginal42da61123f891e63201d7be28f403427; ?>
<?php unset($__attributesOriginal42da61123f891e63201d7be28f403427); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42da61123f891e63201d7be28f403427)): ?>
<?php $component = $__componentOriginal42da61123f891e63201d7be28f403427; ?>
<?php unset($__componentOriginal42da61123f891e63201d7be28f403427); ?>
<?php endif; ?>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php if(request()->is('/') || request()->is('savings') || request()->is('business')): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/index.js']); ?>
    <?php elseif(request()->is('about') || request()->is('career')): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/about.js']); ?>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body class="font-sans antialiased <?php echo e(request()->is('about') ? 'bg-accent-black text-white' : 'text-gray-900'); ?>">
    <?php if (isset($component)) { $__componentOriginal8c1b382543e4a0f754cb1109547c7c68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c1b382543e4a0f754cb1109547c7c68 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pages.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c1b382543e4a0f754cb1109547c7c68)): ?>
<?php $attributes = $__attributesOriginal8c1b382543e4a0f754cb1109547c7c68; ?>
<?php unset($__attributesOriginal8c1b382543e4a0f754cb1109547c7c68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c1b382543e4a0f754cb1109547c7c68)): ?>
<?php $component = $__componentOriginal8c1b382543e4a0f754cb1109547c7c68; ?>
<?php unset($__componentOriginal8c1b382543e4a0f754cb1109547c7c68); ?>
<?php endif; ?>


    <div class="">
        <?php echo e($slot); ?>

    </div>

    <?php if (isset($component)) { $__componentOriginale1a5dc06883efde99c738294c04804ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1a5dc06883efde99c738294c04804ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pages.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $attributes = $__attributesOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__attributesOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $component = $__componentOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__componentOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/layouts/guest.blade.php ENDPATH**/ ?>