<?php $__env->startSection('title', isset($post) && $post->title ? $post->title : 'Blog Post'); ?>
<?php $__env->startSection('meta_description',
    isset($post) && $post->excerpt
    ? $post->excerpt
    : 'Insights, guides, and updates from
    DgnRavePay.'); ?>
    <?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php
            $cover =
                isset($post) && $post->cover_image_path
                    ? asset('storage/' . $post->cover_image_path)
                    : asset('images/logo wide.png');
            $pub =
                isset($post) && $post->published_at
                    ? \Illuminate\Support\Carbon::parse($post->published_at)->toIso8601String()
                    : null;
            $articleSchema = [
                '@context' => 'https://schema.org',
                '@type' => 'BlogPosting',
                'headline' => $post->title ?? 'Blog Post',
                'image' => [$cover],
                'author' => [
                    '@type' => 'Person',
                    'name' => $post->author ?? 'DgnRavePay',
                ],
                'datePublished' => $pub,
                'mainEntityOfPage' => url()->current(),
                'description' => $post->excerpt ?? null,
            ];
        ?>
        <?php $__env->startPush('head'); ?>
            <?php if (isset($component)) { $__componentOriginal42da61123f891e63201d7be28f403427 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42da61123f891e63201d7be28f403427 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seo','data' => ['jsonLd' => $articleSchema,'title' => null,'description' => null,'onlyJsonLd' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('seo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['jsonLd' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($articleSchema),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(null),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(null),'onlyJsonLd' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42da61123f891e63201d7be28f403427)): ?>
<?php $attributes = $__attributesOriginal42da61123f891e63201d7be28f403427; ?>
<?php unset($__attributesOriginal42da61123f891e63201d7be28f403427); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42da61123f891e63201d7be28f403427)): ?>
<?php $component = $__componentOriginal42da61123f891e63201d7be28f403427; ?>
<?php unset($__componentOriginal42da61123f891e63201d7be28f403427); ?>
<?php endif; ?>
        <?php $__env->stopPush(); ?>
        <div class="custom-container mx-auto  px-5 md:px-10 pb-10 pt-40 md:pt-52">
            <div class="text-center text-xs md:text-sm">
                <?php echo e($post->author ?? 'DgnRavePay Team'); ?> •
                <span
                    class="text-stone-400"><?php echo e(optional(\Illuminate\Support\Carbon::parse($post->published_at))->toFormattedDateString()); ?></span>
            </div>
            <h2 class="max-w-5xl mx-auto font-bold text-center mt-10 mb-20"><?php echo e($post->title); ?></h2>
            <img src="<?php echo e($cover); ?>" alt="<?php echo e($post->title); ?>" class="w-full rounded-xl aspect-video mb-10 object-cover">

            <div class="md:grid md:grid-cols-10 md:gap-5 border-b border-slate-200 pb-20">
                <div class="col-span-3">
                    <div class="flex items-center gap-3">
                        <img src="<?php echo e(Vite::asset('resources/images/profile.jpg')); ?>" alt="Author"
                            class="h-10 rounded-full">
                        <p class="text-stone-600 text-xs md:text-sm font-semibold"><?php echo e($post->author ?? 'DgnRavePay Team'); ?>

                        </p>
                    </div>
                    <p class="text-stone-600 text-xs md:text-sm uppercase mt-10 mb-3">share this post</p>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(url()->current())); ?>&text=<?php echo e(urlencode($post->title)); ?>"
                        class="px-3 py-2 bg-black rounded-full text-white font-medium text-xs md:text-sm items-center gap-1 inline-flex"
                        target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-4 stroke-white">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                        </svg>
                        <span>Post</span>
                    </a>
                </div>
                <div class="col-span-7 mt-10 md:mt-0 prose prose-stone max-w-none">
                    <?php if($post->relationLoaded('tags') ? $post->tags->isNotEmpty() : $post->tags()->exists()): ?>
                        <div class="not-prose mb-6 flex flex-wrap gap-2">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/blog?tag=<?php echo e($tag->slug); ?>"
                                    class="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs uppercase">#<?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php echo \App\Support\HtmlSanitizer::clean($post->content); ?>

                </div>
            </div>
            <section class="my-20">
                <div>
                    <p class="text-xs md:text-sm text-slate-600 uppercase ml-2">IF YOU ENJOYED THIS, CHECK THESE OUT</p>
                    <div class="grid md:grid-cols-2 lg:grid-cols-2 gap-5 mt-3">
                        <?php $__currentLoopData = $related ?? collect(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rCover = $r->cover_image_path
                                    ? asset('storage/' . $r->cover_image_path)
                                    : Vite::asset('resources/images/article 1.jpg');
                            ?>
                            <article class="space-y-2">
                                <a href="/blog/<?php echo e($r->slug); ?>">
                                    <img src="<?php echo e($rCover); ?>" alt="<?php echo e($r->title); ?>"
                                        class="aspect-video rounded-xl object-cover">
                                    <h6 class="font-bold text-lg"><?php echo e($r->title); ?></h6>
                                    <p class="font-medium"><?php echo e($r->excerpt); ?></p>
                                    <div class="flex uppercase text-stone-700">
                                        <?php echo e($r->author ?? 'DgnRavePay Team'); ?> -
                                        <?php echo e(optional(\Illuminate\Support\Carbon::parse($r->published_at))->toFormattedDateString()); ?>

                                    </div>
                                </a>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/pages/blog-detail.blade.php ENDPATH**/ ?>