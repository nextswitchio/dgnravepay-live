
<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-bold">Testimonials</h1>
        <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="px-3 py-2 bg-primary text-white rounded">New</a>
    </div>
    <div class="bg-white rounded shadow overflow-x-auto">
        <table class="min-w-full">
            <thead>
                <tr class="text-left text-sm text-gray-600">
                    <th class="p-3">#</th>
                    <th class="p-3">Name</th>
                    <th class="p-3">Rating</th>
                    <th class="p-3">Variant</th>
                    <th class="p-3">Published</th>
                    <th class="p-3">Featured</th>
                    <th class="p-3">Sort</th>
                    <th class="p-3"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="p-3"><?php echo e($t->id); ?></td>
                        <td class="p-3 flex items-center gap-2">
                            <?php if($t->avatar_url): ?>
                                <img src="<?php echo e($t->avatar_url); ?>" alt="<?php echo e($t->name); ?> avatar"
                                    class="w-8 h-8 rounded-full object-cover" />
                            <?php endif; ?>
                            <div>
                                <div class="font-medium"><?php echo e($t->name); ?></div>
                                <div class="text-xs text-gray-500 line-clamp-1"><?php echo e(strip_tags($t->content)); ?></div>
                            </div>
                        </td>
                        <td class="p-3"><?php echo e($t->rating); ?>★</td>
                        <td class="p-3"><?php echo e(ucfirst($t->variant)); ?></td>
                        <td class="p-3"><?php echo $t->is_published
                            ? '<span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">Yes</span>'
                            : '<span class="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">No</span>'; ?></td>
                        <td class="p-3"><?php echo $t->is_featured
                            ? '<span class="px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded">Yes</span>'
                            : '<span class="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">No</span>'; ?></td>
                        <td class="p-3"><?php echo e($t->sort_order); ?></td>
                        <td class="p-3 text-right">
                            <a href="<?php echo e(route('admin.testimonials.edit', $t)); ?>"
                                class="text-blue-600 hover:underline">Edit</a>
                            <form action="<?php echo e(route('admin.testimonials.destroy', $t)); ?>" method="POST" class="inline"
                                onsubmit="return confirm('Delete this testimonial?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="text-red-600 hover:underline ml-2">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($testimonials->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samue\dgnravepay-live-main\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>